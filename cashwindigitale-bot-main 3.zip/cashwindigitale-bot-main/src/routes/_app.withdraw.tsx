import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { useStore, formatFCFA, COUNTRIES, PAYMENT_METHODS, findCountry } from "@/lib/store";
import { toast } from "sonner";
import { ExternalLink, Clock } from "lucide-react";

export const Route = createFileRoute("/_app/withdraw")({
  head: () => ({ meta: [{ title: "Retrait — Cash Win Digital" }] }),
  component: Withdraw,
});

const FEES_URL = "https://new.sebpay.bj/pay/frais-de-transaction-pyxtjH";

function Withdraw() {
  const { currentUser, requestWithdraw, updateUser } = useStore();
  const navigate = useNavigate();
  const [country, setCountry] = useState(currentUser?.countryCode ?? "TG");
  const [method, setMethod] = useState("orange");
  const [number, setNumber] = useState("");
  const [amount, setAmount] = useState(5100);
  const [phase, setPhase] = useState<"form" | "countdown" | "sent" | "feesWait">("form");
  const [secs, setSecs] = useState(10);
  const [feeSecs, setFeeSecs] = useState(59);

  useEffect(() => {
    if (phase === "countdown") {
      if (secs <= 0) {
        finalize();
        return;
      }
      const t = setTimeout(() => setSecs((s) => s - 1), 1000);
      return () => clearTimeout(t);
    }
    if (phase === "feesWait") {
      if (feeSecs <= 0) {
        setPhase("form");
        setFeeSecs(59);
        toast.error("Délai expiré. Réessayez après paiement des frais.");
        return;
      }
      const t = setTimeout(() => setFeeSecs((s) => s - 1), 1000);
      return () => clearTimeout(t);
    }
  }, [phase, secs, feeSecs]);

  if (!currentUser) return null;

  const hour = new Date().getHours();
  const inHours = hour >= 7 && hour < 17;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentUser.activated) return toast.error("Activez votre compte pour retirer.");
    if (!inHours) return toast.error("Retraits autorisés de 07h00 à 17h00.");
    if (amount < 5100) return toast.error("Minimum : 5 100 FCFA.");
    if (amount > currentUser.balance) return toast.error("Solde insuffisant.");
    if (number.trim().length < 6) return toast.error("Numéro invalide.");
    setPhase("countdown");
    setSecs(10);
  };

  const finalize = () => {
    setPhase("sent");
    setTimeout(() => setPhase("feesWait"), 1500);
  };

  const confirmFeesPaid = () => {
    requestWithdraw({
      userId: currentUser.id,
      userName: currentUser.name,
      phone: `${findCountry(country).dial} ${number}`,
      country: findCountry(country).name,
      amount,
      method: PAYMENT_METHODS.find((m) => m.id === method)?.name ?? method,
    });
    updateUser(currentUser.id, { balance: currentUser.balance - amount });
    toast.success("Demande de retrait envoyée à l'administrateur.");
    navigate({ to: "/dashboard" });
  };

  if (phase === "countdown") {
    return (
      <Centered>
        <Clock className="h-10 w-10 text-gold mx-auto" />
        <div className="text-4xl font-extrabold mt-3">{secs}s</div>
        <p className="text-muted-foreground mt-2">Préparation de votre demande…</p>
      </Centered>
    );
  }

  if (phase === "sent") {
    return (
      <Centered>
        <div className="text-2xl font-bold text-gold">Demande envoyée avec succès</div>
        <p className="text-muted-foreground mt-2">Veuillez régler les frais de transaction pour finaliser.</p>
      </Centered>
    );
  }

  if (phase === "feesWait") {
    return (
      <Centered>
        <div className="text-xs uppercase tracking-widest text-muted-foreground">Frais de transaction</div>
        <div className="text-4xl font-extrabold text-gold mt-2">2 100 FCFA</div>
        <a
          href={FEES_URL}
          target="_blank"
          rel="noopener noreferrer"
          className="mt-6 inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 px-6 shadow-gold"
        >
          Payer les frais <ExternalLink className="h-4 w-4" />
        </a>
        <button
          onClick={confirmFeesPaid}
          className="mt-3 block w-full rounded-2xl border border-gold/40 text-gold py-3"
        >
          J'ai déjà payé · {feeSecs}s
        </button>
      </Centered>
    );
  }

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Retrait</h1>
        <p className="text-sm text-muted-foreground">
          Min 5 100 FCFA · 07h–17h ·{" "}
          {inHours ? <span className="text-gold">Ouvert</span> : <span className="text-destructive">Fermé</span>}
        </p>
      </header>

      <form onSubmit={submit} className="glass rounded-2xl p-5 grid gap-4">
        <label className="grid gap-1.5">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Pays</span>
          <select value={country} onChange={(e) => setCountry(e.target.value)} className={inputCls}>
            {COUNTRIES.map((c) => (
              <option key={c.code} value={c.code}>{c.flag} {c.name}</option>
            ))}
          </select>
        </label>

        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground mb-2">Mode de paiement</div>
          <div className="grid grid-cols-3 gap-2">
            {PAYMENT_METHODS.map((m) => (
              <button
                key={m.id}
                type="button"
                onClick={() => setMethod(m.id)}
                className={`rounded-xl p-3 text-xs font-medium border transition ${method === m.id ? "border-gold bg-gold/10" : "border-border bg-surface"}`}
              >
                <span
                  className="block w-7 h-7 mx-auto mb-1.5 rounded-full"
                  style={{ background: m.color }}
                />
                {m.name}
              </button>
            ))}
          </div>
        </div>

        <label className="grid gap-1.5">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Numéro</span>
          <div className="flex gap-2">
            <span className="inline-flex items-center px-3 rounded-xl bg-surface text-gold border border-gold/20">
              {findCountry(country).dial}
            </span>
            <input value={number} onChange={(e) => setNumber(e.target.value)} className={inputCls} inputMode="tel" placeholder="90 00 00 00" />
          </div>
        </label>

        <label className="grid gap-1.5">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Montant (FCFA)</span>
          <input type="number" min={5100} value={amount} onChange={(e) => setAmount(Number(e.target.value))} className={inputCls} />
          <span className="text-xs text-muted-foreground">Solde disponible : {formatFCFA(currentUser.balance)}</span>
        </label>

        <button className="rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold">
          Demander le retrait
        </button>
      </form>
    </div>
  );
}

const inputCls = "w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3";

function Centered({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="glass rounded-3xl p-8 text-center max-w-sm w-full shadow-card">{children}</div>
    </div>
  );
}
