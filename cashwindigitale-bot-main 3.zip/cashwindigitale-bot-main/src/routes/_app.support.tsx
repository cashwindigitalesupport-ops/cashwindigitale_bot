import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import { useStore } from "@/lib/store";
import { Mail, Send } from "lucide-react";

export const Route = createFileRoute("/_app/support")({
  head: () => ({ meta: [{ title: "Support — Cash Win Digital" }] }),
  component: Support,
});

function Support() {
  const { currentUser, db, sendChat } = useStore();
  const [text, setText] = useState("");
  const endRef = useRef<HTMLDivElement>(null);
  const msgs = currentUser ? db.chats.filter((c) => c.userId === currentUser.id) : [];

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [msgs.length]);

  if (!currentUser) return null;

  const send = (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;
    sendChat(currentUser.id, "user", text.trim());
    setText("");
  };

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Support</h1>
        <p className="text-sm text-muted-foreground">Réponse sous 72 heures maximum.</p>
      </header>

      <a
        href="mailto:cashwindigitale.support@gmail.com"
        className="glass rounded-2xl p-4 flex items-center gap-3 hover:border-gold/40 transition"
      >
        <div className="w-10 h-10 rounded-xl bg-gradient-gold text-gold-foreground flex items-center justify-center">
          <Mail className="h-5 w-5" />
        </div>
        <div>
          <div className="font-medium">Email support</div>
          <div className="text-xs text-muted-foreground">cashwindigitale.support@gmail.com</div>
        </div>
      </a>

      <div className="glass rounded-2xl flex flex-col h-[60vh]">
        <div className="px-4 py-3 border-b border-border text-sm font-semibold">Chat direct</div>
        <div className="flex-1 overflow-y-auto px-4 py-3 space-y-2.5">
          {msgs.length === 0 && (
            <div className="text-center text-sm text-muted-foreground py-8">Aucun message. Démarrez la conversation.</div>
          )}
          {msgs.map((m) => (
            <div key={m.id} className={`flex ${m.from === "user" ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[80%] rounded-2xl px-3.5 py-2 text-sm ${m.from === "user" ? "bg-gradient-gold text-gold-foreground" : "bg-surface border border-border"}`}>
                {m.text}
              </div>
            </div>
          ))}
          <div ref={endRef} />
        </div>
        <form onSubmit={send} className="p-3 border-t border-border flex gap-2">
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            placeholder="Écrire un message…"
            className="flex-1 rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-2.5 text-sm"
          />
          <button className="p-2.5 rounded-xl bg-gradient-gold text-gold-foreground">
            <Send className="h-4 w-4" />
          </button>
        </form>
      </div>
    </div>
  );
}
