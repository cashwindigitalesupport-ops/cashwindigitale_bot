import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Logo } from "@/components/Logo";
import { useStore } from "@/lib/store";
import { toast } from "sonner";
import { CheckCircle2, ExternalLink, Clock, LogOut } from "lucide-react";

export const Route = createFileRoute("/activation")({
  head: () => ({ meta: [{ title: "Activation — Cash Win Digital" }] }),
  component: Activation,
});

const PAY_URL = "https://new.sebpay.bj/pay/activation-cSVaGG";

function Activation() {
  const { currentUser, db, requestActivation, logout } = useStore();
  const navigate = useNavigate();
  const [secs, setSecs] = useState(59);

  const pending = currentUser
    ? db.activations.find((a) => a.userId === currentUser.id && a.status === "pending")
    : null;

  // Auto-redirect once admin approves
  useEffect(() => {
    if (currentUser?.activated) {
      toast.success("Compte activé par l'administrateur.");
      navigate({ to: "/dashboard" });
    }
  }, [currentUser?.activated, navigate]);

  // Cycling 59s timer while waiting
  useEffect(() => {
    if (!pending) return;
    const t = setTimeout(() => setSecs((s) => (s <= 1 ? 59 : s - 1)), 1000);
    return () => clearTimeout(t);
  }, [pending, secs]);

  if (!currentUser) {
    return (
      <div className="min-h-screen flex items-center justify-center p-6 text-center">
        <div>
          <p className="text-muted-foreground mb-4">Vous devez être connecté.</p>
          <button onClick={() => navigate({ to: "/login" })} className="text-gold underline">
            Se connecter
          </button>
        </div>
      </div>
    );
  }

  const claimPaid = () => {
    requestActivation(currentUser.id);
    setSecs(59);
    toast.info("Paiement en cours de vérification par l'administrateur.");
  };

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-md px-5 py-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <Logo size={64} />
          <h1 className="text-2xl font-bold">Activez votre compte</h1>
          <p className="text-sm text-muted-foreground">
            Une activation unique débloque les retraits, les Mini Games et le parrainage.
            Seul l'administrateur peut valider l'activation après réception du paiement.
          </p>
        </div>

        <div className="mt-8 glass rounded-3xl p-6 text-center shadow-card">
          <div className="text-xs uppercase tracking-widest text-muted-foreground">Montant d'activation</div>
          <div className="mt-2 text-5xl font-extrabold">
            <span className="text-gold">3 500</span>
            <span className="text-lg text-muted-foreground ml-1">FCFA</span>
          </div>

          {pending ? (
            <div className="mt-6 space-y-3">
              <div className="inline-flex items-center gap-2 text-gold">
                <Clock className="h-5 w-5 animate-pulse" />
                <span className="font-semibold">Paiement en cours de vérification</span>
              </div>
              <p className="text-sm text-muted-foreground">
                Veuillez patienter, l'administrateur valide votre paiement.
              </p>
              <div className="text-4xl font-extrabold text-gold">{secs}s</div>
              <p className="text-xs text-muted-foreground">
                Demande envoyée le {new Date(pending.createdAt).toLocaleString("fr-FR")}.
              </p>
            </div>
          ) : (
            <div className="mt-6 grid gap-3">
              <a
                href={PAY_URL}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold"
              >
                Payer 3 500 FCFA <ExternalLink className="h-4 w-4" />
              </a>
              <button
                onClick={claimPaid}
                className="rounded-2xl border border-gold/40 text-gold font-medium py-3"
              >
                J'ai déjà payé
              </button>
            </div>
          )}
        </div>

        <p className="mt-6 flex items-start gap-2 text-xs text-muted-foreground">
          <CheckCircle2 className="h-4 w-4 mt-0.5 text-gold shrink-0" />
          Aucune activation automatique. Votre compte sera activé uniquement après validation de
          votre paiement par un administrateur.
        </p>

        <button
          onClick={() => {
            logout();
            navigate({ to: "/login" });
          }}
          className="mt-6 mx-auto flex items-center gap-1.5 text-xs text-muted-foreground"
        >
          <LogOut className="h-3.5 w-3.5" /> Se déconnecter
        </button>
      </div>
    </div>
  );
}
