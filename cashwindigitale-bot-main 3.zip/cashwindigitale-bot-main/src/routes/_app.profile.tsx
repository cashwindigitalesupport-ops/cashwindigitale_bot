import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, COUNTRIES, findCountry, formatFCFA } from "@/lib/store";
import { toast } from "sonner";
import { BadgeCheck, Lock, LogOut } from "lucide-react";

export const Route = createFileRoute("/_app/profile")({
  head: () => ({ meta: [{ title: "Profil — Cash Win Digital" }] }),
  component: Profile,
});

function Profile() {
  const { currentUser, updateUser, logout, db } = useStore();
  const navigate = useNavigate();
  const [name, setName] = useState(currentUser?.name ?? "");
  const [phone, setPhone] = useState(currentUser?.phone ?? "");
  const [countryCode, setCountry] = useState(currentUser?.countryCode ?? "TG");
  const [password, setPassword] = useState("");

  if (!currentUser) return null;
  const myWithdraws = db.withdraws.filter((w) => w.userId === currentUser.id);
  const myGains = db.gains.filter((g) => g.userId === currentUser.id).slice(0, 20);

  const save = (e: React.FormEvent) => {
    e.preventDefault();
    updateUser(currentUser.id, {
      name,
      phone,
      countryCode,
      ...(password ? { password } : {}),
    });
    setPassword("");
    toast.success("Profil mis à jour");
  };

  return (
    <div className="space-y-5">
      <header className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">Profil</h1>
          <p className="text-sm text-muted-foreground">ID {currentUser.id}</p>
        </div>
        <button
          onClick={() => { logout(); navigate({ to: "/" }); }}
          className="inline-flex items-center gap-1.5 text-sm text-destructive"
        >
          <LogOut className="h-4 w-4" /> Quitter
        </button>
      </header>

      <div className="glass rounded-2xl p-4 flex items-center justify-between">
        <div>
          <div className="text-xs uppercase tracking-wider text-muted-foreground">Statut</div>
          <div className="mt-1 font-semibold">
            {currentUser.activated
              ? <span className="text-gold inline-flex items-center gap-1.5"><BadgeCheck className="h-4 w-4" /> Activé</span>
              : <span className="text-destructive inline-flex items-center gap-1.5"><Lock className="h-4 w-4" /> Non activé</span>}
          </div>
        </div>
        <div className="text-right">
          <div className="text-xs uppercase text-muted-foreground tracking-wider">Solde</div>
          <div className="font-bold text-gold">{formatFCFA(currentUser.balance)}</div>
        </div>
      </div>

      <form onSubmit={save} className="glass rounded-2xl p-5 grid gap-3">
        <Input label="Nom" value={name} onChange={setName} />
        <Input label="Téléphone" value={phone} onChange={setPhone} />
        <label className="grid gap-1.5">
          <span className="text-xs uppercase tracking-wider text-muted-foreground">Pays</span>
          <select value={countryCode} onChange={(e) => setCountry(e.target.value)} className={cls}>
            {COUNTRIES.map((c) => <option key={c.code} value={c.code}>{c.flag} {c.name} ({c.dial})</option>)}
          </select>
        </label>
        <Input label="Nouveau mot de passe (optionnel)" value={password} onChange={setPassword} type="password" />
        <button className="rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3 shadow-gold">
          Enregistrer
        </button>
      </form>

      <section>
        <h2 className="text-sm font-semibold mb-2">Historique des retraits</h2>
        <div className="glass rounded-2xl divide-y divide-border">
          {myWithdraws.length === 0 ? (
            <div className="p-4 text-sm text-muted-foreground text-center">Aucun retrait</div>
          ) : myWithdraws.map((w) => (
            <div key={w.id} className="px-4 py-3 flex justify-between text-sm">
              <div>
                <div className="font-medium">{formatFCFA(w.amount)} · {w.method}</div>
                <div className="text-xs text-muted-foreground">{new Date(w.createdAt).toLocaleString("fr-FR")}</div>
              </div>
              <span className={`text-xs px-2 py-1 rounded-full self-start ${
                w.status === "paid" ? "bg-emerald-500/15 text-emerald-400" :
                w.status === "rejected" ? "bg-destructive/15 text-destructive" :
                "bg-gold/15 text-gold"
              }`}>
                {w.status === "pending" ? "En attente" : w.status === "paid" ? "Payé" : "Rejeté"}
              </span>
            </div>
          ))}
        </div>
      </section>

      <section>
        <h2 className="text-sm font-semibold mb-2">Historique des gains</h2>
        <div className="glass rounded-2xl divide-y divide-border">
          {myGains.length === 0 ? (
            <div className="p-4 text-sm text-muted-foreground text-center">Aucun gain</div>
          ) : myGains.map((g) => (
            <div key={g.id} className="px-4 py-3 flex justify-between text-sm">
              <div>
                <div className="font-medium capitalize">{g.type}</div>
                <div className="text-xs text-muted-foreground">{g.detail} · {new Date(g.createdAt).toLocaleString("fr-FR")}</div>
              </div>
              <span className={g.amount >= 0 ? "text-gold font-semibold" : "text-destructive font-semibold"}>
                {g.amount >= 0 ? "+" : ""}{formatFCFA(g.amount)}
              </span>
            </div>
          ))}
        </div>
      </section>
    </div>
  );
}

const cls = "w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3";

function Input({ label, value, onChange, type = "text" }: { label: string; value: string; onChange: (v: string) => void; type?: string }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      <input type={type} value={value} onChange={(e) => onChange(e.target.value)} className={cls} />
    </label>
  );
}
