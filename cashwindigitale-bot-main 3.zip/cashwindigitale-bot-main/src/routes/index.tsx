import { createFileRoute, Link } from "@tanstack/react-router";
import { Logo } from "@/components/Logo";
import { Gamepad2, Users, Wallet, ShieldCheck, Hand, FileText, ChevronRight } from "lucide-react";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Cash Win Digital — Bienvenue" },
      { name: "description", content: "Découvrez Cash Win Digital : mini-jeux, parrainage, retraits rapides en FCFA." },
    ],
  }),
  component: Landing,
});

const features = [
  { icon: Gamepad2, title: "Mini-jeux", desc: "Crash, Tower, Mines, Falcon. Misez de 1 000 à 100 000 FCFA, gagnez instantanément." },
  { icon: Hand, title: "Tap Tap", desc: "Chaque clic vous rapporte 15 FCFA, ajoutés automatiquement à votre solde." },
  { icon: Users, title: "Parrainage", desc: "Gagnez 500 FCFA au Niveau 1 et 250 FCFA au Niveau 2 pour chaque filleul activé." },
  { icon: Wallet, title: "Retraits", desc: "De 07h00 à 17h00. Minimum 5 100 FCFA via Orange, MTN, Moov, TMoney, Airtel, Wave." },
  { icon: ShieldCheck, title: "Activation", desc: "Une activation unique à 3 500 FCFA débloque tous les retraits et fonctionnalités." },
  { icon: FileText, title: "Conditions", desc: "En continuant, vous acceptez les conditions générales d'utilisation de la plateforme." },
];

function Landing() {
  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-2xl px-5 py-10">
        <header className="flex flex-col items-center text-center gap-4">
          <Logo size={96} />
          <h1 className="text-3xl sm:text-4xl font-bold leading-tight">
            Bienvenue sur <span className="text-gold">Cash Win Digital</span>
          </h1>
          <p className="text-muted-foreground max-w-md">
            Gagnez dès maintenant et pour toujours. Une plateforme moderne dédiée à l'Afrique francophone.
          </p>
        </header>

        <section className="mt-10 grid gap-3">
          {features.map(({ icon: Icon, title, desc }) => (
            <div key={title} className="glass rounded-2xl p-4 flex gap-4 shadow-card">
              <div className="shrink-0 w-11 h-11 rounded-xl bg-gradient-gold flex items-center justify-center text-gold-foreground">
                <Icon className="h-5 w-5" />
              </div>
              <div>
                <div className="font-semibold">{title}</div>
                <p className="text-sm text-muted-foreground mt-0.5">{desc}</p>
              </div>
            </div>
          ))}
        </section>

        <div className="mt-10 flex flex-col gap-3 sticky bottom-4">
          <Link
            to="/register"
            className="w-full inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-4 shadow-gold hover:opacity-95 transition"
          >
            J'accepte <ChevronRight className="h-5 w-5" />
          </Link>
          <Link to="/login" className="text-center text-sm text-muted-foreground hover:text-gold">
            Déjà inscrit ? <span className="text-gold underline-offset-2 hover:underline">Se connecter</span>
          </Link>
        </div>
      </div>
    </div>
  );
}
