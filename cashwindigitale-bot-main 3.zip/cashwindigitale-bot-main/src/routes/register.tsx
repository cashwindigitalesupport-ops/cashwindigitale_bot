import { createFileRoute, Link, useNavigate, useSearch } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { Logo } from "@/components/Logo";
import { COUNTRIES, findCountry, useStore } from "@/lib/store";
import { toast } from "sonner";

type Search = { ref?: string };

export const Route = createFileRoute("/register")({
  validateSearch: (s: Record<string, unknown>): Search => ({
    ref: typeof s.ref === "string" ? s.ref : undefined,
  }),
  head: () => ({ meta: [{ title: "Inscription — Cash Win Digital" }] }),
  component: Register,
});

function Register() {
  const navigate = useNavigate();
  const search = useSearch({ from: "/register" });
  const { register, db } = useStore();
  const [name, setName] = useState("");
  const [phone, setPhone] = useState("");
  const [country, setCountry] = useState("TG");
  const [password, setPassword] = useState("");
  const [promo, setPromo] = useState("WELCOME");
  const dial = useMemo(() => findCountry(country).dial, [country]);

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name.trim() || !phone.trim() || password.length < 4) {
      toast.error("Merci de remplir tous les champs (mot de passe ≥ 4 caractères).");
      return;
    }
    const exists = db.users.find((u) => u.phone === `${dial} ${phone.trim()}`);
    if (exists) {
      toast.error("Ce numéro est déjà utilisé.");
      return;
    }
    const validPromo = db.promos.find((p) => p.code === promo.trim().toUpperCase());
    if (!validPromo) {
      toast.error("Code promo invalide. Utilisez WELCOME.");
      return;
    }
    const u = register({
      name: name.trim(),
      phone: `${dial} ${phone.trim()}`,
      countryCode: country,
      password,
      promo: promo.trim().toUpperCase(),
      ref: search.ref ?? null,
    });
    toast.success(`Compte créé · Votre ID : ${u.id}`);
    navigate({ to: "/activation" });
  };

  return (
    <div className="min-h-screen">
      <div className="mx-auto max-w-md px-5 py-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <Logo size={64} />
          <h1 className="text-2xl font-bold">Créer un compte</h1>
          <p className="text-sm text-muted-foreground">Rejoignez Cash Win Digital en moins d'une minute.</p>
        </div>

        <form onSubmit={submit} className="mt-8 grid gap-4 glass rounded-2xl p-5 shadow-card">
          <Field label="Nom complet">
            <input value={name} onChange={(e) => setName(e.target.value)} placeholder="Jean Dupont" className={input} />
          </Field>

          <Field label="Pays">
            <select value={country} onChange={(e) => setCountry(e.target.value)} className={input}>
              {COUNTRIES.map((c) => (
                <option key={c.code} value={c.code}>
                  {c.flag} {c.name} ({c.dial})
                </option>
              ))}
            </select>
          </Field>

          <Field label="Numéro de téléphone">
            <div className="flex gap-2">
              <span className="inline-flex items-center px-3 rounded-xl bg-surface text-gold font-medium border border-gold/20">
                {dial}
              </span>
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value.replace(/[^\d ]/g, ""))}
                placeholder="90 00 00 00"
                className={input}
                inputMode="tel"
              />
            </div>
          </Field>

          <Field label="Mot de passe">
            <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} placeholder="••••••••" className={input} />
          </Field>

          <Field label="Code promo">
            <input value={promo} onChange={(e) => setPromo(e.target.value.toUpperCase())} className={input} />
          </Field>

          {search.ref && (
            <div className="text-xs text-gold">Parrainé par {search.ref}</div>
          )}

          <button type="submit" className="mt-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold">
            S'inscrire
          </button>
        </form>

        <p className="text-center text-sm text-muted-foreground mt-6">
          Déjà membre ? <Link to="/login" className="text-gold">Connexion</Link>
        </p>
      </div>
    </div>
  );
}

const input = "w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3 text-foreground placeholder:text-muted-foreground/60 transition";

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}
