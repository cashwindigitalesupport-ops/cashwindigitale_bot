import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { Rocket, Building2, Bomb, Bird, Lock, BadgeCheck } from "lucide-react";
import { useStore } from "@/lib/store";

export const Route = createFileRoute("/_app/mini-games")({
  head: () => ({ meta: [{ title: "Mini Games — Cash Win Digital" }] }),
  component: MiniGames,
});

const games = [
  { id: "crash", name: "Crash", icon: Rocket, desc: "Encaissez avant le crash.", tint: "from-amber-400/30 to-amber-600/10" },
  { id: "tower", name: "Tower", icon: Building2, desc: "Grimpez sans tomber.", tint: "from-sky-400/30 to-sky-600/10" },
  { id: "mines", name: "Mines", icon: Bomb, desc: "Évitez les mines, doublez la mise.", tint: "from-emerald-400/30 to-emerald-600/10" },
  { id: "falcon", name: "Falcon", icon: Bird, desc: "Pilotez le faucon doré.", tint: "from-rose-400/30 to-rose-600/10" },
];

function MiniGames() {
  const { currentUser } = useStore();
  const navigate = useNavigate();

  if (currentUser && !currentUser.activated) {
    return (
      <div className="space-y-5">
        <header>
          <h1 className="text-2xl font-bold">Mini Games</h1>
        </header>
        <div className="glass rounded-3xl p-8 text-center shadow-card">
          <div className="w-14 h-14 rounded-full bg-destructive/15 text-destructive mx-auto flex items-center justify-center">
            <Lock className="h-7 w-7" />
          </div>
          <h2 className="mt-4 text-lg font-semibold">Compte non activé</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Votre compte n'est pas encore activé. Vous devez activer votre compte pour accéder aux
            Mini Games.
          </p>
          <button
            onClick={() => navigate({ to: "/activation" })}
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3 px-6 shadow-gold"
          >
            <BadgeCheck className="h-5 w-5" /> Activer mon compte
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Mini Games</h1>
        <p className="text-sm text-muted-foreground">Mise min 1 000 · max 100 000 FCFA</p>
      </header>
      <div className="grid grid-cols-2 gap-3">
        {games.map((g) => (
          <Link
            key={g.id}
            to="/mini-games/$game"
            params={{ game: g.id }}
            className="relative overflow-hidden rounded-2xl p-4 glass hover:border-gold/40 transition"
          >
            <div className={`absolute inset-0 bg-gradient-to-br ${g.tint} opacity-60`} />
            <div className="relative">
              <g.icon className="h-7 w-7 text-gold mb-3" />
              <div className="font-bold text-lg">{g.name}</div>
              <div className="text-xs text-muted-foreground mt-1">{g.desc}</div>
            </div>
          </Link>
        ))}
      </div>
    </div>
  );
}
