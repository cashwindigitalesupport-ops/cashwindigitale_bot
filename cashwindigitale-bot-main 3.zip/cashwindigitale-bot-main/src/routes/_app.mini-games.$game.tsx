import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { useStore, formatFCFA } from "@/lib/store";
import { toast } from "sonner";
import { ArrowLeft, BadgeCheck, Lock, Play, HandCoins, RotateCcw, Bomb as BombIcon, Gem, Bird } from "lucide-react";

export const Route = createFileRoute("/_app/mini-games/$game")({
  head: () => ({ meta: [{ title: "Jeu — Cash Win Digital" }] }),
  component: GamePlay,
});

const NAMES: Record<string, string> = {
  crash: "Crash",
  tower: "Tower",
  mines: "Mines",
  falcon: "Falcon",
};

// Deterministic seeded RNG (anti-fraud audit trail)
function seededRand(seed: string) {
  let h = 2166136261;
  for (let i = 0; i < seed.length; i++) {
    h ^= seed.charCodeAt(i);
    h = Math.imul(h, 16777619);
  }
  return () => {
    h += 0x6D2B79F5;
    let t = h;
    t = Math.imul(t ^ (t >>> 15), t | 1);
    t ^= t + Math.imul(t ^ (t >>> 7), t | 61);
    return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
  };
}

function GamePlay() {
  const { game } = Route.useParams();
  const { currentUser } = useStore();
  const navigate = useNavigate();

  if (!currentUser) return null;
  const name = NAMES[game] ?? "Jeu";

  if (!currentUser.activated) {
    return (
      <div className="space-y-5">
        <Link to="/mini-games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-gold">
          <ArrowLeft className="h-4 w-4" /> Retour
        </Link>
        <div className="glass rounded-3xl p-8 text-center shadow-card">
          <div className="w-14 h-14 rounded-full bg-destructive/15 text-destructive mx-auto flex items-center justify-center">
            <Lock className="h-7 w-7" />
          </div>
          <h2 className="mt-4 text-lg font-semibold">Compte non activé</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            Votre compte n'est pas encore activé. Vous devez activer votre compte pour accéder aux Mini Games.
          </p>
          <button
            onClick={() => navigate({ to: "/activation" })}
            className="mt-6 inline-flex items-center justify-center gap-2 rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3 px-6 shadow-gold"
          >
            <BadgeCheck className="h-5 w-5" /> Activer mon compte
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-5">
      <Link to="/mini-games" className="inline-flex items-center gap-1 text-sm text-muted-foreground hover:text-gold">
        <ArrowLeft className="h-4 w-4" /> Retour
      </Link>
      <header>
        <h1 className="text-2xl font-bold">{name}</h1>
        <p className="text-sm text-muted-foreground">
          Solde : <span className="text-gold">{formatFCFA(currentUser.balance)}</span>
        </p>
      </header>

      {game === "crash" && <CrashGame />}
      {game === "tower" && <TowerGame />}
      {game === "mines" && <MinesGame />}
      {game === "falcon" && <FalconGame />}
    </div>
  );
}

// ---------- Shared stake controls ----------
function StakeBox({
  stake,
  setStake,
  disabled,
}: {
  stake: number;
  setStake: (n: number) => void;
  disabled?: boolean;
}) {
  return (
    <div className="glass rounded-2xl p-4 grid gap-3">
      <label className="grid gap-1.5">
        <span className="text-xs uppercase tracking-wider text-muted-foreground">Mise (FCFA)</span>
        <input
          type="number"
          min={1000}
          max={100000}
          value={stake}
          onChange={(e) => setStake(Number(e.target.value))}
          disabled={disabled}
          className="w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3 disabled:opacity-60"
        />
      </label>
      <div className="grid grid-cols-4 gap-2">
        {[1000, 5000, 10000, 50000].map((v) => (
          <button
            key={v}
            disabled={disabled}
            onClick={() => setStake(v)}
            className="rounded-lg bg-surface border border-border text-xs py-2 hover:border-gold/40 disabled:opacity-50"
          >
            {v.toLocaleString("fr-FR")}
          </button>
        ))}
      </div>
    </div>
  );
}

function validateStake(stake: number, balance: number): string | null {
  if (!Number.isFinite(stake)) return "Mise invalide.";
  if (stake < 1000 || stake > 100000) return "Mise entre 1 000 et 100 000 FCFA.";
  if (stake > balance) return "Solde insuffisant.";
  return null;
}

// ---------- CRASH ----------
function CrashGame() {
  const { currentUser, updateUser, addGain, recordRound, canPlay } = useStore();
  const [stake, setStake] = useState(1000);
  const [multi, setMulti] = useState(1);
  const [running, setRunning] = useState(false);
  const [crashed, setCrashed] = useState(false);
  const crashAtRef = useRef(0);
  const cashedRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = () => {
    if (!currentUser) return;
    const err = validateStake(stake, currentUser.balance);
    if (err) return toast.error(err);
    const fraud = canPlay(currentUser.id);
    if (!fraud.ok) return toast.error(fraud.reason!);

    const seed = `${currentUser.id}-${Date.now()}`;
    const rng = seededRand(seed);
    // crash point distribution biased toward house edge
    const r = rng();
    const crashAt = Math.max(1.01, Math.min(15, +(0.95 / (1 - r * 0.97)).toFixed(2)));
    crashAtRef.current = crashAt;
    cashedRef.current = false;

    updateUser(currentUser.id, {
      balance: currentUser.balance - stake,
      totalInvested: currentUser.totalInvested + stake,
    });
    setMulti(1);
    setCrashed(false);
    setRunning(true);

    let m = 1;
    timerRef.current = setInterval(() => {
      m = +(m + 0.04 + m * 0.012).toFixed(2);
      setMulti(m);
      if (m >= crashAtRef.current) {
        clearInterval(timerRef.current!);
        timerRef.current = null;
        setRunning(false);
        if (!cashedRef.current) {
          setCrashed(true);
          recordRound({ userId: currentUser.id, game: "crash", stake, multiplier: m, payout: 0, win: false, seed });
          toast.error(`Crash à ×${m.toFixed(2)}. Mise perdue.`);
        }
      }
    }, 120);
  };

  const cashout = () => {
    if (!running || !currentUser) return;
    cashedRef.current = true;
    const m = multi;
    const payout = Math.round(stake * m);
    addGain(currentUser.id, "game", payout, `Crash ×${m.toFixed(2)}`);
    recordRound({ userId: currentUser.id, game: "crash", stake, multiplier: m, payout, win: true, seed: `${currentUser.id}-cashed` });
    setRunning(false);
    if (timerRef.current) clearInterval(timerRef.current);
    toast.success(`Encaissé ${formatFCFA(payout)} (×${m.toFixed(2)})`);
  };

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  return (
    <>
      <div className="glass rounded-3xl p-8 text-center shadow-card relative overflow-hidden">
        <div className="text-xs uppercase tracking-widest text-muted-foreground">Multiplicateur</div>
        <div
          className={`mt-3 text-6xl font-extrabold transition ${
            crashed ? "text-destructive" : running ? "text-gold" : "text-foreground"
          }`}
        >
          ×{multi.toFixed(2)}
        </div>
        {crashed && <div className="mt-2 text-sm text-destructive">💥 Crashé</div>}
      </div>

      <StakeBox stake={stake} setStake={setStake} disabled={running} />

      {!running ? (
        <button
          onClick={start}
          className="w-full rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold inline-flex items-center justify-center gap-2"
        >
          <Play className="h-4 w-4" /> Commencer
        </button>
      ) : (
        <button
          onClick={cashout}
          className="w-full rounded-2xl bg-emerald-500 text-white font-semibold py-3.5 inline-flex items-center justify-center gap-2"
        >
          <HandCoins className="h-4 w-4" /> Encaisser {formatFCFA(Math.round(stake * multi))}
        </button>
      )}
    </>
  );
}

// ---------- TOWER ----------
const TOWER_LEVELS = 8;
function TowerGame() {
  const { currentUser, updateUser, addGain, recordRound, canPlay } = useStore();
  const [stake, setStake] = useState(1000);
  const [level, setLevel] = useState(0);
  const [active, setActive] = useState(false);
  const [seed, setSeed] = useState("");
  const [safeMap, setSafeMap] = useState<number[]>([]);

  const multiplier = useMemo(() => +(1 + level * 0.35).toFixed(2), [level]);
  const potential = Math.round(stake * multiplier);

  const startGame = () => {
    if (!currentUser) return;
    const err = validateStake(stake, currentUser.balance);
    if (err) return toast.error(err);
    const fraud = canPlay(currentUser.id);
    if (!fraud.ok) return toast.error(fraud.reason!);

    const s = `${currentUser.id}-${Date.now()}`;
    const rng = seededRand(s);
    // For each level pick safe column (0..2)
    const map = Array.from({ length: TOWER_LEVELS }, () => Math.floor(rng() * 3));
    setSeed(s);
    setSafeMap(map);
    updateUser(currentUser.id, {
      balance: currentUser.balance - stake,
      totalInvested: currentUser.totalInvested + stake,
    });
    setLevel(0);
    setActive(true);
  };

  const pick = (col: number) => {
    if (!active || !currentUser) return;
    if (safeMap[level] === col) {
      const newLevel = level + 1;
      if (newLevel >= TOWER_LEVELS) {
        const m = +(1 + newLevel * 0.35).toFixed(2);
        const payout = Math.round(stake * m);
        addGain(currentUser.id, "game", payout, `Tower top ×${m}`);
        recordRound({ userId: currentUser.id, game: "tower", stake, multiplier: m, payout, win: true, seed });
        toast.success(`Sommet ! +${formatFCFA(payout)}`);
        setActive(false);
        setLevel(0);
      } else {
        setLevel(newLevel);
      }
    } else {
      recordRound({ userId: currentUser.id, game: "tower", stake, multiplier, payout: 0, win: false, seed });
      toast.error("Vous êtes tombé. Mise perdue.");
      setActive(false);
      setLevel(0);
    }
  };

  const cashout = () => {
    if (!active || !currentUser || level === 0) return;
    addGain(currentUser.id, "game", potential, `Tower ×${multiplier}`);
    recordRound({ userId: currentUser.id, game: "tower", stake, multiplier, payout: potential, win: true, seed });
    toast.success(`Encaissé ${formatFCFA(potential)}`);
    setActive(false);
    setLevel(0);
  };

  return (
    <>
      <div className="glass rounded-3xl p-5 shadow-card">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Niveau {level}/{TOWER_LEVELS}</span>
          <span className="text-gold font-semibold">×{multiplier} · {formatFCFA(potential)}</span>
        </div>
        <div className="mt-4 flex flex-col-reverse gap-1.5">
          {Array.from({ length: TOWER_LEVELS }).map((_, lvl) => {
            const reached = lvl < level;
            const current = lvl === level && active;
            return (
              <div key={lvl} className="grid grid-cols-3 gap-1.5">
                {[0, 1, 2].map((col) => (
                  <button
                    key={col}
                    onClick={() => current && pick(col)}
                    disabled={!current}
                    className={`h-10 rounded-lg border transition ${
                      reached
                        ? safeMap[lvl] === col
                          ? "bg-emerald-500/30 border-emerald-500/60"
                          : "bg-surface border-border opacity-40"
                        : current
                          ? "bg-gold/10 border-gold/40 hover:bg-gold/20"
                          : "bg-surface border-border opacity-50"
                    }`}
                  >
                    {reached && safeMap[lvl] === col ? "✓" : ""}
                  </button>
                ))}
              </div>
            );
          })}
        </div>
      </div>

      {!active ? (
        <>
          <StakeBox stake={stake} setStake={setStake} />
          <button
            onClick={startGame}
            className="w-full rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold inline-flex items-center justify-center gap-2"
          >
            <Play className="h-4 w-4" /> Commencer
          </button>
        </>
      ) : (
        <button
          onClick={cashout}
          disabled={level === 0}
          className="w-full rounded-2xl bg-emerald-500 text-white font-semibold py-3.5 disabled:opacity-50 inline-flex items-center justify-center gap-2"
        >
          <HandCoins className="h-4 w-4" /> Encaisser {formatFCFA(potential)}
        </button>
      )}
    </>
  );
}

// ---------- MINES ----------
const MINES_SIZE = 25;
function MinesGame() {
  const { currentUser, updateUser, addGain, recordRound, canPlay } = useStore();
  const [stake, setStake] = useState(1000);
  const [mineCount, setMineCount] = useState(5);
  const [active, setActive] = useState(false);
  const [mines, setMines] = useState<Set<number>>(new Set());
  const [opened, setOpened] = useState<Set<number>>(new Set());
  const [seed, setSeed] = useState("");

  const safeFound = opened.size;
  const totalSafe = MINES_SIZE - mineCount;
  const multiplier = useMemo(() => {
    let m = 1;
    for (let i = 0; i < safeFound; i++) {
      m *= (MINES_SIZE - i) / (totalSafe - i);
    }
    return +(m * 0.97).toFixed(2);
  }, [safeFound, totalSafe]);
  const potential = Math.round(stake * multiplier);

  const start = () => {
    if (!currentUser) return;
    const err = validateStake(stake, currentUser.balance);
    if (err) return toast.error(err);
    if (mineCount < 1 || mineCount > 20) return toast.error("1 à 20 mines.");
    const fraud = canPlay(currentUser.id);
    if (!fraud.ok) return toast.error(fraud.reason!);

    const s = `${currentUser.id}-${Date.now()}`;
    const rng = seededRand(s);
    const set = new Set<number>();
    while (set.size < mineCount) set.add(Math.floor(rng() * MINES_SIZE));
    setMines(set);
    setOpened(new Set());
    setSeed(s);
    updateUser(currentUser.id, {
      balance: currentUser.balance - stake,
      totalInvested: currentUser.totalInvested + stake,
    });
    setActive(true);
  };

  const open = (i: number) => {
    if (!active || opened.has(i) || !currentUser) return;
    if (mines.has(i)) {
      recordRound({ userId: currentUser.id, game: "mines", stake, multiplier, payout: 0, win: false, seed });
      toast.error("💣 Mine ! Mise perdue.");
      setOpened(new Set([...opened, i]));
      setActive(false);
      return;
    }
    const next = new Set([...opened, i]);
    setOpened(next);
    if (next.size === totalSafe) {
      // auto cashout
      const m = +(multiplier * ((MINES_SIZE - safeFound) / (totalSafe - safeFound))).toFixed(2);
      const p = Math.round(stake * m);
      addGain(currentUser.id, "game", p, `Mines ×${m}`);
      recordRound({ userId: currentUser.id, game: "mines", stake, multiplier: m, payout: p, win: true, seed });
      toast.success(`Tout dévoilé ! +${formatFCFA(p)}`);
      setActive(false);
    }
  };

  const cashout = () => {
    if (!active || safeFound === 0 || !currentUser) return;
    addGain(currentUser.id, "game", potential, `Mines ×${multiplier}`);
    recordRound({ userId: currentUser.id, game: "mines", stake, multiplier, payout: potential, win: true, seed });
    toast.success(`Encaissé ${formatFCFA(potential)}`);
    setActive(false);
  };

  return (
    <>
      <div className="glass rounded-3xl p-5 shadow-card">
        <div className="flex items-center justify-between text-xs mb-3">
          <span className="text-muted-foreground">{safeFound} cases · {mineCount} mines</span>
          <span className="text-gold font-semibold">×{multiplier} · {formatFCFA(potential)}</span>
        </div>
        <div className="grid grid-cols-5 gap-1.5">
          {Array.from({ length: MINES_SIZE }).map((_, i) => {
            const isOpen = opened.has(i);
            const isMine = mines.has(i);
            const reveal = !active && (isOpen || isMine);
            return (
              <button
                key={i}
                onClick={() => open(i)}
                disabled={!active || isOpen}
                className={`aspect-square rounded-lg border flex items-center justify-center transition ${
                  isOpen && !isMine
                    ? "bg-emerald-500/30 border-emerald-500/60"
                    : reveal && isMine
                      ? "bg-destructive/40 border-destructive/60"
                      : "bg-surface border-border hover:border-gold/40"
                }`}
              >
                {isOpen && !isMine && <Gem className="h-4 w-4 text-emerald-300" />}
                {reveal && isMine && <BombIcon className="h-4 w-4 text-destructive" />}
              </button>
            );
          })}
        </div>
      </div>

      {!active ? (
        <>
          <StakeBox stake={stake} setStake={setStake} />
          <div className="glass rounded-2xl p-4">
            <label className="grid gap-1.5">
              <span className="text-xs uppercase tracking-wider text-muted-foreground">Mines : {mineCount}</span>
              <input
                type="range"
                min={1}
                max={20}
                value={mineCount}
                onChange={(e) => setMineCount(Number(e.target.value))}
                className="accent-[oklch(0.83_0.16_85)]"
              />
            </label>
          </div>
          <button
            onClick={start}
            className="w-full rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold inline-flex items-center justify-center gap-2"
          >
            <Play className="h-4 w-4" /> Commencer
          </button>
        </>
      ) : (
        <button
          onClick={cashout}
          disabled={safeFound === 0}
          className="w-full rounded-2xl bg-emerald-500 text-white font-semibold py-3.5 disabled:opacity-50 inline-flex items-center justify-center gap-2"
        >
          <HandCoins className="h-4 w-4" /> Encaisser {formatFCFA(potential)}
        </button>
      )}
    </>
  );
}

// ---------- FALCON ----------
function FalconGame() {
  const { currentUser, updateUser, addGain, recordRound, canPlay } = useStore();
  const [stake, setStake] = useState(1000);
  const [running, setRunning] = useState(false);
  const [crashed, setCrashed] = useState(false);
  const [multi, setMulti] = useState(1);
  const [pos, setPos] = useState(0);
  const crashAtRef = useRef(0);
  const cashedRef = useRef(false);
  const timerRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const start = () => {
    if (!currentUser) return;
    const err = validateStake(stake, currentUser.balance);
    if (err) return toast.error(err);
    const fraud = canPlay(currentUser.id);
    if (!fraud.ok) return toast.error(fraud.reason!);

    const seed = `${currentUser.id}-${Date.now()}`;
    const rng = seededRand(seed);
    const r = rng();
    const crashAt = Math.max(1.05, Math.min(8, +(1 + r * r * 6).toFixed(2)));
    crashAtRef.current = crashAt;
    cashedRef.current = false;

    updateUser(currentUser.id, {
      balance: currentUser.balance - stake,
      totalInvested: currentUser.totalInvested + stake,
    });
    setMulti(1);
    setPos(0);
    setCrashed(false);
    setRunning(true);

    let m = 1;
    let p = 0;
    timerRef.current = setInterval(() => {
      m = +(m + 0.06).toFixed(2);
      p = Math.min(95, p + 2.2);
      setMulti(m);
      setPos(p);
      if (m >= crashAtRef.current) {
        clearInterval(timerRef.current!);
        timerRef.current = null;
        setRunning(false);
        if (!cashedRef.current) {
          setCrashed(true);
          recordRound({ userId: currentUser.id, game: "falcon", stake, multiplier: m, payout: 0, win: false, seed });
          toast.error(`Chute à ×${m}. Mise perdue.`);
        }
      }
    }, 150);
  };

  const cashout = () => {
    if (!running || !currentUser) return;
    cashedRef.current = true;
    const m = multi;
    const payout = Math.round(stake * m);
    addGain(currentUser.id, "game", payout, `Falcon ×${m}`);
    recordRound({ userId: currentUser.id, game: "falcon", stake, multiplier: m, payout, win: true, seed: `${currentUser.id}-cashed` });
    if (timerRef.current) clearInterval(timerRef.current);
    setRunning(false);
    toast.success(`Encaissé ${formatFCFA(payout)}`);
  };

  useEffect(() => () => { if (timerRef.current) clearInterval(timerRef.current); }, []);

  return (
    <>
      <div className="glass rounded-3xl p-6 shadow-card">
        <div className="text-xs uppercase tracking-widest text-muted-foreground text-center">Multiplicateur</div>
        <div className={`mt-1 text-5xl font-extrabold text-center ${crashed ? "text-destructive" : running ? "text-gold" : "text-foreground"}`}>
          ×{multi.toFixed(2)}
        </div>
        <div className="mt-6 relative h-24 bg-gradient-to-r from-sky-500/10 to-amber-500/10 rounded-2xl overflow-hidden border border-border">
          <div
            className="absolute bottom-2 transition-all duration-150"
            style={{ left: `${pos}%`, transform: crashed ? "rotate(80deg) translateY(20px)" : "rotate(-12deg)" }}
          >
            <Bird className={`h-10 w-10 ${crashed ? "text-destructive" : "text-gold"}`} />
          </div>
          <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-gold" />
        </div>
      </div>

      <StakeBox stake={stake} setStake={setStake} disabled={running} />

      {!running ? (
        <button
          onClick={start}
          className="w-full rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold inline-flex items-center justify-center gap-2"
        >
          {crashed ? <RotateCcw className="h-4 w-4" /> : <Play className="h-4 w-4" />} {crashed ? "Rejouer" : "Commencer"}
        </button>
      ) : (
        <button
          onClick={cashout}
          className="w-full rounded-2xl bg-emerald-500 text-white font-semibold py-3.5 inline-flex items-center justify-center gap-2"
        >
          <HandCoins className="h-4 w-4" /> Encaisser {formatFCFA(Math.round(stake * multi))}
        </button>
      )}
    </>
  );
}
