import { createFileRoute } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { useStore, formatFCFA } from "@/lib/store";
import { toast } from "sonner";
import {
  Shield, ShieldAlert, Users, Wallet, Ticket, Trash2, Ban, BadgeCheck, X, Check, Pencil,
  Search, History, Filter, FileCheck2,
} from "lucide-react";

export const Route = createFileRoute("/_app/admin")({
  head: () => ({ meta: [{ title: "Administration — Cash Win Digital" }] }),
  component: Admin,
});

function Admin() {
  const { isAdmin, setAdmin } = useStore();
  const [code, setCode] = useState("");

  if (!isAdmin) {
    return (
      <div className="space-y-5">
        <header className="text-center">
          <ShieldAlert className="h-12 w-12 mx-auto text-gold" />
          <h1 className="mt-3 text-2xl font-bold">Administration</h1>
          <p className="text-sm text-muted-foreground">Accès réservé aux administrateurs</p>
        </header>
        <div className="glass rounded-2xl p-5 max-w-sm mx-auto">
          <input
            type="password"
            value={code}
            onChange={(e) => setCode(e.target.value)}
            placeholder="Code administrateur"
            className="w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3"
          />
          <button
            onClick={() => {
              if (code === "cashwin2026") {
                setAdmin(true);
                toast.success("Accès administrateur accordé");
              } else {
                toast.error("Code incorrect");
              }
            }}
            className="mt-3 w-full rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3 shadow-gold"
          >
            Valider
          </button>
        </div>
      </div>
    );
  }
  return <AdminPanel />;
}

type Tab = "activations" | "withdraws" | "users" | "promos" | "history";

function AdminPanel() {
  const { db, updateUser, updateWithdraw, approveActivation, rejectActivation, addPromo, setAdmin } = useStore();
  const [tab, setTab] = useState<Tab>("activations");

  return (
    <div className="space-y-5">
      <header className="flex items-center justify-between">
        <div className="inline-flex items-center gap-2">
          <Shield className="h-6 w-6 text-gold" />
          <h1 className="text-2xl font-bold">Admin</h1>
        </div>
        <button onClick={() => setAdmin(false)} className="text-sm text-muted-foreground">Quitter</button>
      </header>

      <div className="glass rounded-xl p-1 grid grid-cols-5 text-xs">
        {([
          { id: "activations", label: "Activ.", icon: BadgeCheck },
          { id: "withdraws", label: "Retraits", icon: Wallet },
          { id: "users", label: "Users", icon: Users },
          { id: "promos", label: "Promos", icon: Ticket },
          { id: "history", label: "Hist.", icon: History },
        ] as const).map((t) => (
          <button
            key={t.id}
            onClick={() => setTab(t.id)}
            className={`rounded-lg py-2 inline-flex flex-col items-center gap-0.5 ${
              tab === t.id ? "bg-gradient-gold text-gold-foreground" : "text-muted-foreground"
            }`}
          >
            <t.icon className="h-4 w-4" /> {t.label}
          </button>
        ))}
      </div>

      {tab === "activations" && <ActivationsPanel approve={approveActivation} reject={rejectActivation} />}
      {tab === "withdraws" && <WithdrawsPanel updateWithdraw={updateWithdraw} />}
      {tab === "users" && <UsersPanel updateUser={updateUser} />}
      {tab === "promos" && <PromoForm onSubmit={addPromo} promos={db.promos} />}
      {tab === "history" && <HistoryPanel />}
    </div>
  );
}

// -------- Activations --------
function ActivationsPanel({
  approve,
  reject,
}: {
  approve: (id: string) => void;
  reject: (id: string, reason: string) => void;
}) {
  const { db } = useStore();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | "pending" | "approved" | "rejected">("pending");

  const filtered = db.activations.filter((a) => {
    if (status !== "all" && a.status !== status) return false;
    if (!q) return true;
    const s = q.toLowerCase();
    return a.userName.toLowerCase().includes(s) || a.userId.toLowerCase().includes(s) || a.phone.includes(q);
  });

  return (
    <>
      <SearchFilter q={q} setQ={setQ} status={status} setStatus={setStatus} />
      {filtered.length === 0 ? (
        <Empty label="Aucune demande." />
      ) : (
        <div className="space-y-2">
          {filtered.map((a) => (
            <div key={a.id} className="glass rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{a.userName}</div>
                  <div className="text-xs text-muted-foreground">{a.userId} · {a.phone}</div>
                  <div className="text-xs text-muted-foreground">{new Date(a.createdAt).toLocaleString("fr-FR")}</div>
                  {a.reason && <div className="text-xs text-destructive mt-1">Motif: {a.reason}</div>}
                </div>
                <StatusPill status={a.status} />
              </div>
              {a.status === "pending" && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <Act onClick={() => approve(a.id)}><Check className="h-3.5 w-3.5" /> Activer le compte</Act>
                  <Act
                    danger
                    onClick={() => {
                      const r = prompt("Motif du rejet ?") ?? "";
                      if (r) reject(a.id, r);
                    }}
                  >
                    <X className="h-3.5 w-3.5" /> Refuser
                  </Act>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

// -------- Withdraws --------
function WithdrawsPanel({ updateWithdraw }: { updateWithdraw: (id: string, p: { status?: "pending" | "paid" | "rejected"; reason?: string; amount?: number }) => void }) {
  const { db } = useStore();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | "pending" | "paid" | "rejected">("pending");

  const filtered = db.withdraws.filter((w) => {
    if (status !== "all" && w.status !== status) return false;
    if (!q) return true;
    const s = q.toLowerCase();
    return w.userName.toLowerCase().includes(s) || w.userId.toLowerCase().includes(s) || w.phone.includes(q);
  });

  return (
    <>
      <SearchFilter q={q} setQ={setQ} status={status} setStatus={setStatus} statuses={["all", "pending", "paid", "rejected"]} />
      {filtered.length === 0 ? (
        <Empty label="Aucune demande." />
      ) : (
        <div className="space-y-2">
          {filtered.map((w) => (
            <div key={w.id} className="glass rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div>
                  <div className="font-semibold">{w.userName} · {formatFCFA(w.amount)}</div>
                  <div className="text-xs text-muted-foreground">{w.method} · {w.phone} · {w.country}</div>
                  <div className="text-xs text-muted-foreground">{new Date(w.createdAt).toLocaleString("fr-FR")}</div>
                  {w.reason && <div className="text-xs text-destructive mt-1">Motif: {w.reason}</div>}
                </div>
                <StatusPill status={w.status} />
              </div>
              {w.status === "pending" && (
                <div className="mt-3 flex flex-wrap gap-2">
                  <Act onClick={() => updateWithdraw(w.id, { status: "paid" })}><Check className="h-3.5 w-3.5" /> Payer</Act>
                  <Act
                    danger
                    onClick={() => {
                      const reason = prompt("Motif du rejet ?") ?? "";
                      if (reason) updateWithdraw(w.id, { status: "rejected", reason });
                    }}
                  >
                    <X className="h-3.5 w-3.5" /> Rejeter
                  </Act>
                  <Act
                    onClick={() => {
                      const v = Number(prompt("Nouveau montant ?", String(w.amount)) ?? w.amount);
                      if (!isNaN(v)) updateWithdraw(w.id, { amount: v });
                    }}
                  >
                    <Pencil className="h-3.5 w-3.5" /> Modifier
                  </Act>
                </div>
              )}
            </div>
          ))}
        </div>
      )}
    </>
  );
}

// -------- Users --------
function UsersPanel({ updateUser }: { updateUser: (id: string, p: Partial<{ activated: boolean; banned: boolean }>) => void }) {
  const { db } = useStore();
  const [q, setQ] = useState("");
  const [status, setStatus] = useState<"all" | "active" | "pending" | "banned">("all");

  const filtered = db.users.filter((u) => {
    if (status === "active" && !u.activated) return false;
    if (status === "pending" && u.activated) return false;
    if (status === "banned" && !u.banned) return false;
    if (!q) return true;
    const s = q.toLowerCase();
    return u.name.toLowerCase().includes(s) || u.id.toLowerCase().includes(s) || u.phone.includes(q);
  });

  return (
    <>
      <SearchFilter q={q} setQ={setQ} status={status} setStatus={setStatus} statuses={["all", "active", "pending", "banned"]} />
      {filtered.length === 0 ? (
        <Empty label="Aucun utilisateur." />
      ) : (
        <div className="space-y-2">
          {filtered.map((u) => (
            <div key={u.id} className="glass rounded-2xl p-4">
              <div className="flex items-start justify-between gap-3">
                <div className="min-w-0">
                  <div className="font-semibold truncate">{u.name}</div>
                  <div className="text-xs text-muted-foreground truncate">{u.id} · {u.phone} · {u.countryCode}</div>
                  <div className="text-xs text-muted-foreground">Solde: {formatFCFA(u.balance)}</div>
                </div>
                <div className="flex flex-col items-end gap-1">
                  <StatusPill status={u.activated ? "approved" : "pending"} />
                  {u.banned && <span className="text-[10px] text-destructive">banni</span>}
                </div>
              </div>
              <div className="mt-3 flex flex-wrap gap-1.5">
                <Act onClick={() => updateUser(u.id, { activated: !u.activated })}>
                  <BadgeCheck className="h-3.5 w-3.5" /> {u.activated ? "Désactiver" : "Activer"}
                </Act>
                <Act onClick={() => updateUser(u.id, { banned: !u.banned })}>
                  <Ban className="h-3.5 w-3.5" /> {u.banned ? "Débannir" : "Bannir"}
                </Act>
                <Act danger onClick={() => toast.info("Suppression désactivée en démo")}>
                  <Trash2 className="h-3.5 w-3.5" /> Suppr.
                </Act>
              </div>
            </div>
          ))}
        </div>
      )}
    </>
  );
}

// -------- History --------
function HistoryPanel() {
  const { db } = useStore();
  const items = useMemo(() => {
    const a = db.activations
      .filter((x) => x.status !== "pending")
      .map((x) => ({
        kind: "Activation",
        label: `${x.userName} · ${x.userId}`,
        status: x.status,
        date: x.resolvedAt ?? x.createdAt,
        detail: x.reason,
      }));
    const w = db.withdraws
      .filter((x) => x.status !== "pending")
      .map((x) => ({
        kind: "Retrait",
        label: `${x.userName} · ${formatFCFA(x.amount)}`,
        status: x.status,
        date: x.resolvedAt ?? x.createdAt,
        detail: x.reason,
      }));
    return [...a, ...w].sort((x, y) => y.date - x.date).slice(0, 100);
  }, [db]);

  if (items.length === 0) return <Empty label="Aucun historique." />;
  return (
    <div className="glass rounded-2xl divide-y divide-border">
      {items.map((it, i) => (
        <div key={i} className="px-4 py-3 flex items-start justify-between gap-3">
          <div className="min-w-0">
            <div className="text-xs text-gold uppercase tracking-wider">{it.kind}</div>
            <div className="font-medium text-sm truncate">{it.label}</div>
            <div className="text-xs text-muted-foreground">{new Date(it.date).toLocaleString("fr-FR")}</div>
            {it.detail && <div className="text-xs text-destructive mt-0.5">{it.detail}</div>}
          </div>
          <StatusPill status={it.status as "approved" | "paid" | "rejected"} />
        </div>
      ))}
    </div>
  );
}

// -------- Promo (kept) --------
function PromoForm({
  onSubmit,
  promos,
}: {
  onSubmit: (p: { code: string; bonus: number; maxUses: number; uses: number; expiresAt: number }) => void;
  promos: { code: string; bonus: number; maxUses: number; uses: number; expiresAt: number }[];
}) {
  const [code, setCode] = useState("");
  const [bonus, setBonus] = useState(0);
  const [max, setMax] = useState(100);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("23:59");

  return (
    <div className="space-y-4">
      <form
        onSubmit={(e) => {
          e.preventDefault();
          if (!code.trim() || !date) return toast.error("Code et date requis.");
          onSubmit({
            code: code.trim().toUpperCase(),
            bonus,
            maxUses: max,
            uses: 0,
            expiresAt: new Date(`${date}T${time}`).getTime(),
          });
          setCode("");
          toast.success("Code promo créé");
        }}
        className="glass rounded-2xl p-5 grid gap-3"
      >
        <Field label="Code promo"><input value={code} onChange={(e) => setCode(e.target.value.toUpperCase())} className={cls} /></Field>
        <Field label="Montant du bonus"><input type="number" value={bonus} onChange={(e) => setBonus(Number(e.target.value))} className={cls} /></Field>
        <Field label="Utilisateurs max"><input type="number" value={max} onChange={(e) => setMax(Number(e.target.value))} className={cls} /></Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="Date expiration"><input type="date" value={date} onChange={(e) => setDate(e.target.value)} className={cls} /></Field>
          <Field label="Heure"><input type="time" value={time} onChange={(e) => setTime(e.target.value)} className={cls} /></Field>
        </div>
        <button className="rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3 shadow-gold">Créer le code promo</button>
      </form>

      <div className="glass rounded-2xl divide-y divide-border">
        {promos.map((p) => (
          <div key={p.code} className="px-4 py-3 flex items-center justify-between text-sm">
            <div>
              <div className="font-semibold text-gold">{p.code}</div>
              <div className="text-xs text-muted-foreground">
                Bonus {formatFCFA(p.bonus)} · {p.uses}/{p.maxUses} · exp. {new Date(p.expiresAt).toLocaleString("fr-FR")}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// -------- Helpers --------
function SearchFilter<T extends string>({
  q,
  setQ,
  status,
  setStatus,
  statuses = ["all", "pending", "approved", "rejected"] as unknown as T[],
}: {
  q: string;
  setQ: (s: string) => void;
  status: T;
  setStatus: (s: T) => void;
  statuses?: T[];
}) {
  return (
    <div className="glass rounded-2xl p-3 space-y-2">
      <div className="relative">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
        <input
          value={q}
          onChange={(e) => setQ(e.target.value)}
          placeholder="Rechercher (nom, ID, téléphone)"
          className="w-full pl-9 pr-3 py-2.5 rounded-xl bg-surface border border-border focus:border-gold focus:outline-none text-sm"
        />
      </div>
      <div className="flex items-center gap-1.5 overflow-x-auto">
        <Filter className="h-3.5 w-3.5 text-muted-foreground shrink-0" />
        {statuses.map((s) => (
          <button
            key={s}
            onClick={() => setStatus(s)}
            className={`px-2.5 py-1 rounded-full text-xs whitespace-nowrap border transition ${
              status === s ? "bg-gradient-gold text-gold-foreground border-transparent" : "border-border text-muted-foreground"
            }`}
          >
            {s}
          </button>
        ))}
      </div>
    </div>
  );
}

function StatusPill({ status }: { status: string }) {
  const tone =
    status === "paid" || status === "approved" || status === "active"
      ? "bg-emerald-500/15 text-emerald-400"
      : status === "rejected" || status === "banned"
        ? "bg-destructive/15 text-destructive"
        : "bg-gold/15 text-gold";
  return <span className={`text-[10px] px-2 py-1 rounded-full font-semibold ${tone}`}>{status}</span>;
}

function Act({ children, onClick, danger }: { children: React.ReactNode; onClick: () => void; danger?: boolean }) {
  return (
    <button
      onClick={onClick}
      className={`inline-flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs border transition ${
        danger ? "border-destructive/40 text-destructive hover:bg-destructive/10" : "border-gold/30 text-gold hover:bg-gold/10"
      }`}
    >
      {children}
    </button>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <label className="grid gap-1.5">
      <span className="text-xs uppercase tracking-wider text-muted-foreground">{label}</span>
      {children}
    </label>
  );
}

function Empty({ label }: { label: string }) {
  return (
    <div className="glass rounded-2xl p-6 text-center text-sm text-muted-foreground inline-flex flex-col items-center gap-2 w-full">
      <FileCheck2 className="h-6 w-6 text-muted-foreground" />
      {label}
    </div>
  );
}

const cls = "w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3";
