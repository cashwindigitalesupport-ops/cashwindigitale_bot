import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { useStore, formatFCFA } from "@/lib/store";
import { Hand } from "lucide-react";

export const Route = createFileRoute("/_app/tap-tap")({
  head: () => ({ meta: [{ title: "Tap Tap — Cash Win Digital" }] }),
  component: TapTap,
});

function TapTap() {
  const { currentUser, addGain, db } = useStore();
  const [pulse, setPulse] = useState(0);
  if (!currentUser) return null;
  const history = db.gains.filter((g) => g.userId === currentUser.id && g.type === "tap").slice(0, 10);

  const tap = () => {
    addGain(currentUser.id, "tap", 15, "Tap");
    setPulse((p) => p + 1);
  };

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Tap Tap</h1>
        <p className="text-sm text-muted-foreground">+15 FCFA par clic, ajoutés instantanément.</p>
      </header>

      <div className="glass rounded-3xl p-6 text-center">
        <div className="text-xs uppercase tracking-widest text-muted-foreground">Solde</div>
        <div className="text-3xl font-extrabold text-gold mt-1">{formatFCFA(currentUser.balance)}</div>
      </div>

      <div className="flex justify-center py-8">
        <button
          onClick={tap}
          key={pulse}
          className="relative w-56 h-56 rounded-full bg-gradient-gold text-gold-foreground font-extrabold text-xl shadow-gold active:scale-95 transition-transform"
        >
          <div className="flex flex-col items-center gap-2">
            <Hand className="h-12 w-12" />
            +15 FCFA
          </div>
          <span className="absolute inset-0 rounded-full ring-2 ring-gold/40 animate-ping" />
        </button>
      </div>

      <div>
        <div className="text-sm font-semibold mb-2">Historique</div>
        <div className="glass rounded-2xl divide-y divide-border">
          {history.length === 0 ? (
            <div className="p-4 text-sm text-muted-foreground text-center">Aucun tap pour le moment.</div>
          ) : (
            history.map((g) => (
              <div key={g.id} className="flex justify-between px-4 py-3 text-sm">
                <span className="text-muted-foreground">{new Date(g.createdAt).toLocaleString("fr-FR")}</span>
                <span className="text-gold font-semibold">+{formatFCFA(g.amount)}</span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}
