import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Logo } from "@/components/Logo";
import { useStore } from "@/lib/store";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Connexion — Cash Win Digital" }] }),
  component: Login,
});

function Login() {
  const { login } = useStore();
  const navigate = useNavigate();
  const [phone, setPhone] = useState("");
  const [password, setPassword] = useState("");

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    const u = login(phone.trim(), password);
    if (!u) {
      toast.error("Identifiants invalides.");
      return;
    }
    toast.success(`Bienvenue ${u.name}`);
    navigate({ to: u.activated ? "/dashboard" : "/activation" });
  };

  return (
    <div className="min-h-screen flex items-center">
      <div className="mx-auto w-full max-w-md px-5 py-8">
        <div className="flex flex-col items-center gap-3 text-center">
          <Logo size={64} />
          <h1 className="text-2xl font-bold">Connexion</h1>
          <p className="text-sm text-muted-foreground">Saisissez votre numéro complet (ex. +228 90 00 00 00).</p>
        </div>
        <form onSubmit={submit} className="mt-8 grid gap-4 glass rounded-2xl p-5 shadow-card">
          <input
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            placeholder="+228 90 00 00 00"
            className="w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3"
          />
          <input
            type="password"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            placeholder="Mot de passe"
            className="w-full rounded-xl bg-surface border border-border focus:border-gold focus:outline-none px-3.5 py-3"
          />
          <button className="rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-3.5 shadow-gold">
            Se connecter
          </button>
        </form>
        <p className="text-center text-sm text-muted-foreground mt-6">
          Pas de compte ? <Link to="/register" className="text-gold">Créer un compte</Link>
        </p>
      </div>
    </div>
  );
}
