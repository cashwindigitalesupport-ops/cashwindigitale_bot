import { createFileRoute, Link } from "@tanstack/react-router";
import { useStore, formatFCFA } from "@/lib/store";
import { ArrowDownToLine, BadgeCheck, Gamepad2, Hand, TrendingUp, Trophy, Users, Lock } from "lucide-react";

export const Route = createFileRoute("/_app/dashboard")({
  head: () => ({ meta: [{ title: "Accueil — Cash Win Digital" }] }),
  component: Dashboard,
});

function Dashboard() {
  const { currentUser, db } = useStore();
  if (!currentUser) return null;
  const referrals = db.users.filter((u) => u.referredBy === currentUser.id);
  const activatedRefs = referrals.filter((u) => u.activated).length;

  return (
    <div className="space-y-5">
      <div>
        <p className="text-muted-foreground text-sm">Bienvenue,</p>
        <h1 className="text-2xl font-bold">{currentUser.name}</h1>
        <div className="mt-1 inline-flex items-center gap-1.5 text-xs">
          {currentUser.activated ? (
            <span className="inline-flex items-center gap-1 text-gold"><BadgeCheck className="h-3.5 w-3.5" /> Compte activé</span>
          ) : (
            <span className="inline-flex items-center gap-1 text-destructive"><Lock className="h-3.5 w-3.5" /> Compte non activé</span>
          )}
          <span className="text-muted-foreground">· ID {currentUser.id}</span>
        </div>
      </div>

      <div className="rounded-3xl p-5 bg-gradient-navy gold-ring shadow-card relative overflow-hidden">
        <div className="absolute -right-10 -top-10 w-48 h-48 rounded-full bg-gradient-gold opacity-20 blur-2xl" />
        <div className="text-xs uppercase tracking-widest text-gold/80">Solde principal</div>
        <div className="mt-2 text-4xl font-extrabold">
          {formatFCFA(currentUser.balance)}
        </div>
        <div className="mt-1 text-sm text-muted-foreground">
          Gains cumulés : <span className="text-gold">{formatFCFA(currentUser.gains)}</span>
        </div>
      </div>

      <Link
        to="/withdraw"
        className="block rounded-2xl bg-gradient-gold text-gold-foreground font-semibold py-4 text-center shadow-gold"
      >
        <span className="inline-flex items-center gap-2">
          <ArrowDownToLine className="h-5 w-5" /> Retrait
        </span>
      </Link>

      <div className="grid grid-cols-3 gap-3">
        <Stat icon={TrendingUp} label="Total Investi" value={formatFCFA(currentUser.totalInvested)} />
        <Stat icon={Trophy} label="Gains" value={formatFCFA(currentUser.gains)} highlight />
        <Stat icon={Users} label="Filleuls actifs" value={`${activatedRefs}/${referrals.length}`} />
      </div>

      <div className="grid grid-cols-2 gap-3">
        <ActionCard to="/mini-games" icon={Gamepad2} title="Mini Games" desc="Crash · Tower · Mines · Falcon" />
        <ActionCard to="/tap-tap" icon={Hand} title="Tap Tap" desc="+15 FCFA par clic" />
      </div>

      <div className="glass rounded-2xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <div className="text-sm font-medium">Votre code promo</div>
            <div className="text-xs text-muted-foreground">Partagez et gagnez 500 FCFA par filleul activé</div>
          </div>
          <span className="px-3 py-1.5 rounded-full bg-gold/15 text-gold text-sm font-semibold">{currentUser.promo}</span>
        </div>
      </div>
    </div>
  );
}

function Stat({ icon: Icon, label, value, highlight }: { icon: React.ElementType; label: string; value: string; highlight?: boolean }) {
  return (
    <div className="glass rounded-2xl p-3.5">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-2 ${highlight ? "bg-gradient-gold text-gold-foreground" : "bg-surface text-gold"}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="text-[11px] uppercase text-muted-foreground tracking-wider">{label}</div>
      <div className="text-sm font-bold mt-0.5">{value}</div>
    </div>
  );
}

function ActionCard({ to, icon: Icon, title, desc }: { to: string; icon: React.ElementType; title: string; desc: string }) {
  return (
    <Link to={to} className="glass rounded-2xl p-4 hover:border-gold/40 transition group">
      <Icon className="h-6 w-6 text-gold mb-2" />
      <div className="font-semibold group-hover:text-gold transition">{title}</div>
      <div className="text-xs text-muted-foreground mt-0.5">{desc}</div>
    </Link>
  );
}
