import { createFileRoute } from "@tanstack/react-router";
import { useStore, formatFCFA } from "@/lib/store";
import { Copy, Users, BadgeCheck, Clock, Wallet } from "lucide-react";
import { toast } from "sonner";

export const Route = createFileRoute("/_app/team")({
  head: () => ({ meta: [{ title: "Mon Équipe — Cash Win Digital" }] }),
  component: Team,
});

function Team() {
  const { currentUser, db } = useStore();
  if (!currentUser) return null;
  const link = typeof window !== "undefined"
    ? `${window.location.origin}/register?ref=${currentUser.id}`
    : `/register?ref=${currentUser.id}`;
  const refs = db.users.filter((u) => u.referredBy === currentUser.id);
  const activated = refs.filter((u) => u.activated);
  const refGains = db.gains
    .filter((g) => g.userId === currentUser.id && g.type === "referral")
    .reduce((s, g) => s + g.amount, 0);

  return (
    <div className="space-y-5">
      <header>
        <h1 className="text-2xl font-bold">Mon Équipe</h1>
        <p className="text-sm text-muted-foreground">N1 : 500 FCFA · N2 : 250 FCFA par activation</p>
      </header>

      <div className="glass rounded-2xl p-4">
        <div className="text-xs uppercase tracking-wider text-muted-foreground">Votre lien de parrainage</div>
        <div className="mt-2 flex items-center gap-2">
          <code className="flex-1 truncate text-sm text-gold bg-surface rounded-lg px-3 py-2 border border-border">{link}</code>
          <button
            onClick={() => {
              navigator.clipboard?.writeText(link);
              toast.success("Lien copié");
            }}
            className="p-2.5 rounded-lg bg-gradient-gold text-gold-foreground"
            aria-label="Copier"
          >
            <Copy className="h-4 w-4" />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 gap-3">
        <Tile icon={Users} label="Filleuls" value={refs.length} />
        <Tile icon={BadgeCheck} label="Activés" value={activated.length} />
        <Tile icon={Clock} label="Non activés" value={refs.length - activated.length} />
        <Tile icon={Wallet} label="Gains parrainage" value={formatFCFA(refGains)} highlight />
      </div>

      <div>
        <div className="text-sm font-semibold mb-2">Liste des filleuls</div>
        <div className="glass rounded-2xl divide-y divide-border">
          {refs.length === 0 ? (
            <div className="p-6 text-center text-sm text-muted-foreground">
              Partagez votre lien pour commencer à gagner.
            </div>
          ) : (
            refs.map((r) => (
              <div key={r.id} className="flex items-center justify-between px-4 py-3 text-sm">
                <div>
                  <div className="font-medium">{r.name}</div>
                  <div className="text-xs text-muted-foreground">{r.id}</div>
                </div>
                <span className={`text-xs px-2 py-1 rounded-full ${r.activated ? "bg-gold/15 text-gold" : "bg-surface text-muted-foreground"}`}>
                  {r.activated ? "Activé" : "En attente"}
                </span>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
}

function Tile({ icon: Icon, label, value, highlight }: { icon: React.ElementType; label: string; value: string | number; highlight?: boolean }) {
  return (
    <div className="glass rounded-2xl p-4">
      <div className={`w-9 h-9 rounded-lg flex items-center justify-center mb-2 ${highlight ? "bg-gradient-gold text-gold-foreground" : "bg-surface text-gold"}`}>
        <Icon className="h-4 w-4" />
      </div>
      <div className="text-[11px] uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-bold mt-0.5">{value}</div>
    </div>
  );
}
