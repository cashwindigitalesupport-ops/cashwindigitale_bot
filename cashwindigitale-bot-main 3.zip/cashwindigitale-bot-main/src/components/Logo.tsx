import logo from "@/assets/cashwin-logo.png.asset.json";

export function Logo({ size = 48, withText = false }: { size?: number; withText?: boolean }) {
  return (
    <div className="flex items-center gap-3">
      <img
        src={logo.url}
        alt="Cash Win Digital"
        width={size}
        height={size}
        className="rounded-lg object-cover"
        style={{ width: size, height: size }}
      />
      {withText && (
        <div className="leading-tight">
          <div className="font-bold tracking-tight">
            <span className="text-foreground">CASH </span>
            <span className="text-gold">WIN</span>
          </div>
          <div className="text-[10px] uppercase tracking-[0.2em] text-gold/80">Digital</div>
        </div>
      )}
    </div>
  );
}
