import { Link } from "@tanstack/react-router";
import { Logo } from "./Logo";
import { Shield, Bell, BadgeCheck, Wallet, Headphones, Info } from "lucide-react";
import { useState } from "react";
import { useStore } from "@/lib/store";

const ICONS = {
  activation: BadgeCheck,
  withdraw: Wallet,
  support: Headphones,
  system: Info,
} as const;

export function AppHeader() {
  const { currentUser, db, markAllRead } = useStore();
  const [open, setOpen] = useState(false);
  const notes = currentUser
    ? db.notifications.filter((n) => n.userId === currentUser.id).slice(0, 30)
    : [];
  const unread = notes.filter((n) => !n.read).length;

  return (
    <header className="sticky top-0 z-30 glass border-b border-gold/15">
      <div className="mx-auto max-w-2xl px-4 py-3 flex items-center justify-between">
        <Link to="/dashboard" className="flex items-center gap-2">
          <Logo size={36} withText />
        </Link>
        <div className="flex items-center gap-2 relative">
          <Link
            to="/admin"
            className="p-2 rounded-full bg-surface text-muted-foreground hover:text-gold transition"
            aria-label="Administration"
          >
            <Shield className="h-4 w-4" />
          </Link>
          <button
            onClick={() => {
              setOpen((o) => !o);
              if (!open && currentUser) setTimeout(() => markAllRead(currentUser.id), 800);
            }}
            className="relative p-2 rounded-full bg-surface text-muted-foreground hover:text-gold transition"
            aria-label="Notifications"
          >
            <Bell className="h-4 w-4" />
            {unread > 0 && (
              <span className="absolute -top-0.5 -right-0.5 min-w-4 h-4 px-1 rounded-full bg-gold text-gold-foreground text-[10px] font-bold flex items-center justify-center">
                {unread}
              </span>
            )}
          </button>
          {open && (
            <div className="absolute right-0 top-12 w-80 max-h-[70vh] overflow-y-auto glass rounded-2xl shadow-card border border-gold/20 z-50">
              <div className="px-4 py-3 border-b border-border flex items-center justify-between">
                <div className="font-semibold text-sm">Notifications</div>
                <button
                  onClick={() => setOpen(false)}
                  className="text-xs text-muted-foreground"
                >
                  Fermer
                </button>
              </div>
              {notes.length === 0 ? (
                <div className="p-6 text-center text-sm text-muted-foreground">
                  Aucune notification.
                </div>
              ) : (
                <ul className="divide-y divide-border">
                  {notes.map((n) => {
                    const Icon = ICONS[n.kind];
                    return (
                      <li key={n.id} className={`px-4 py-3 ${!n.read ? "bg-gold/5" : ""}`}>
                        <div className="flex gap-3">
                          <div className="w-8 h-8 rounded-lg bg-surface text-gold flex items-center justify-center shrink-0">
                            <Icon className="h-4 w-4" />
                          </div>
                          <div className="min-w-0 flex-1">
                            <div className="text-sm font-medium">{n.title}</div>
                            <div className="text-xs text-muted-foreground mt-0.5">{n.body}</div>
                            <div className="text-[10px] text-muted-foreground mt-1 flex items-center gap-2">
                              <span>{new Date(n.createdAt).toLocaleString("fr-FR")}</span>
                              {n.emailSent && <span className="text-gold">· email envoyé</span>}
                            </div>
                          </div>
                        </div>
                      </li>
                    );
                  })}
                </ul>
              )}
            </div>
          )}
        </div>
      </div>
    </header>
  );
}
