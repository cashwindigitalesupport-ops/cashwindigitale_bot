import { Link, useRouterState } from "@tanstack/react-router";
import { Home, Gamepad2, Hand, Users, Headphones, User } from "lucide-react";

const items = [
  { to: "/dashboard", label: "Accueil", icon: Home },
  { to: "/mini-games", label: "Mini Games", icon: Gamepad2 },
  { to: "/tap-tap", label: "Tap Tap", icon: Hand },
  { to: "/team", label: "Équipe", icon: Users },
  { to: "/support", label: "Support", icon: Headphones },
  { to: "/profile", label: "Profil", icon: User },
] as const;

export function BottomNav() {
  const pathname = useRouterState({ select: (s) => s.location.pathname });
  return (
    <nav className="fixed bottom-0 inset-x-0 z-40 glass border-t border-gold/20">
      <ul className="mx-auto max-w-2xl grid grid-cols-6 px-1 py-2">
        {items.map(({ to, label, icon: Icon }) => {
          const active = pathname.startsWith(to);
          return (
            <li key={to}>
              <Link
                to={to}
                className={`flex flex-col items-center gap-1 py-1 text-[10px] transition ${
                  active ? "text-gold" : "text-muted-foreground"
                }`}
              >
                <Icon className="h-5 w-5" />
                <span className="truncate">{label}</span>
              </Link>
            </li>
          );
        })}
      </ul>
    </nav>
  );
}
