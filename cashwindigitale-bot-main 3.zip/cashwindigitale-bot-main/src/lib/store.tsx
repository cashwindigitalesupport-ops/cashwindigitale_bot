import { createContext, useContext, useEffect, useState, type ReactNode } from "react";

export type Country = {
  code: string;
  name: string;
  dial: string;
  flag: string;
};

export const COUNTRIES: Country[] = [
  { code: "TG", name: "Togo", dial: "+228", flag: "🇹🇬" },
  { code: "BJ", name: "Bénin", dial: "+229", flag: "🇧🇯" },
  { code: "BF", name: "Burkina Faso", dial: "+226", flag: "🇧🇫" },
  { code: "CI", name: "Côte d'Ivoire", dial: "+225", flag: "🇨🇮" },
  { code: "SN", name: "Sénégal", dial: "+221", flag: "🇸🇳" },
  { code: "ML", name: "Mali", dial: "+223", flag: "🇲🇱" },
  { code: "NE", name: "Niger", dial: "+227", flag: "🇳🇪" },
  { code: "CM", name: "Cameroun", dial: "+237", flag: "🇨🇲" },
  { code: "TD", name: "Tchad", dial: "+235", flag: "🇹🇩" },
  { code: "GA", name: "Gabon", dial: "+241", flag: "🇬🇦" },
  { code: "CG", name: "Congo-Brazzaville", dial: "+242", flag: "🇨🇬" },
  { code: "CD", name: "RDC", dial: "+243", flag: "🇨🇩" },
  { code: "GN", name: "Guinée", dial: "+224", flag: "🇬🇳" },
];

export const PAYMENT_METHODS = [
  { id: "orange", name: "Orange Money", color: "#ff6600" },
  { id: "mtn", name: "MTN Money", color: "#ffcc00" },
  { id: "moov", name: "Moov Money", color: "#0066cc" },
  { id: "tmoney", name: "TMoney", color: "#1e3a8a" },
  { id: "airtel", name: "Airtel Money", color: "#e60000" },
  { id: "wave", name: "Wave", color: "#1f8eff" },
];

export type User = {
  id: string;
  name: string;
  phone: string;
  countryCode: string;
  password: string;
  promo: string;
  activated: boolean;
  banned: boolean;
  balance: number;
  gains: number;
  totalInvested: number;
  referredBy: string | null;
  createdAt: number;
};

export type WithdrawRequest = {
  id: string;
  userId: string;
  userName: string;
  phone: string;
  country: string;
  amount: number;
  method: string;
  status: "pending" | "paid" | "rejected";
  reason?: string;
  createdAt: number;
  resolvedAt?: number;
};

export type ActivationRequest = {
  id: string;
  userId: string;
  userName: string;
  phone: string;
  status: "pending" | "approved" | "rejected";
  reason?: string;
  createdAt: number;
  resolvedAt?: number;
};

export type GainEntry = {
  id: string;
  userId: string;
  type: "tap" | "game" | "referral" | "bonus";
  amount: number;
  detail?: string;
  createdAt: number;
};

export type GameRound = {
  id: string;
  userId: string;
  game: string;
  stake: number;
  multiplier: number;
  payout: number;
  win: boolean;
  seed: string;
  createdAt: number;
};

export type ChatMessage = {
  id: string;
  userId: string;
  from: "user" | "admin";
  text: string;
  createdAt: number;
};

export type PromoCode = {
  code: string;
  bonus: number;
  maxUses: number;
  uses: number;
  expiresAt: number;
};

export type Notification = {
  id: string;
  userId: string;
  kind: "activation" | "withdraw" | "support" | "system";
  title: string;
  body: string;
  read: boolean;
  emailSent: boolean;
  createdAt: number;
};

type DB = {
  users: User[];
  withdraws: WithdrawRequest[];
  activations: ActivationRequest[];
  gains: GainEntry[];
  rounds: GameRound[];
  chats: ChatMessage[];
  promos: PromoCode[];
  notifications: Notification[];
  lastPlay: Record<string, number>;
  nextUserNum: number;
  currentUserId: string | null;
};

const KEY = "cwd:db:v2";

function defaultDB(): DB {
  return {
    users: [],
    withdraws: [],
    activations: [],
    gains: [],
    rounds: [],
    chats: [],
    promos: [
      { code: "WELCOME", bonus: 0, maxUses: 99999, uses: 0, expiresAt: Date.now() + 365 * 24 * 3600 * 1000 },
    ],
    notifications: [],
    lastPlay: {},
    nextUserNum: 100001,
    currentUserId: null,
  };
}

function loadDB(): DB {
  if (typeof window === "undefined") return defaultDB();
  try {
    const raw = localStorage.getItem(KEY);
    if (!raw) return defaultDB();
    return { ...defaultDB(), ...JSON.parse(raw) };
  } catch {
    return defaultDB();
  }
}

function saveDB(db: DB) {
  if (typeof window === "undefined") return;
  localStorage.setItem(KEY, JSON.stringify(db));
}

type Ctx = {
  db: DB;
  currentUser: User | null;
  register: (
    data: Omit<User, "id" | "activated" | "banned" | "balance" | "gains" | "totalInvested" | "createdAt" | "referredBy"> & { ref?: string | null },
  ) => User;
  login: (phone: string, password: string) => User | null;
  logout: () => void;
  updateUser: (id: string, patch: Partial<User>) => void;
  addGain: (userId: string, type: GainEntry["type"], amount: number, detail?: string) => void;
  recordRound: (r: Omit<GameRound, "id" | "createdAt">) => void;
  canPlay: (userId: string) => { ok: boolean; reason?: string };
  requestWithdraw: (req: Omit<WithdrawRequest, "id" | "status" | "createdAt">) => WithdrawRequest;
  updateWithdraw: (id: string, patch: Partial<WithdrawRequest>) => void;
  requestActivation: (userId: string) => ActivationRequest;
  approveActivation: (id: string) => void;
  rejectActivation: (id: string, reason: string) => void;
  sendChat: (userId: string, from: "user" | "admin", text: string) => void;
  addPromo: (p: PromoCode) => void;
  notify: (userId: string, n: Omit<Notification, "id" | "userId" | "read" | "emailSent" | "createdAt"> & { emailSent?: boolean }) => void;
  markAllRead: (userId: string) => void;
  isAdmin: boolean;
  setAdmin: (v: boolean) => void;
};

const StoreCtx = createContext<Ctx | null>(null);

export function StoreProvider({ children }: { children: ReactNode }) {
  const [db, setDb] = useState<DB>(() => defaultDB());
  const [hydrated, setHydrated] = useState(false);
  const [isAdmin, setAdmin] = useState(false);

  useEffect(() => {
    setDb(loadDB());
    setHydrated(true);
  }, []);

  useEffect(() => {
    if (hydrated) saveDB(db);
  }, [db, hydrated]);

  const currentUser = db.users.find((u) => u.id === db.currentUserId) ?? null;

  const notify: Ctx["notify"] = (userId, n) => {
    const note: Notification = {
      id: crypto.randomUUID(),
      userId,
      read: false,
      emailSent: n.emailSent ?? true,
      createdAt: Date.now(),
      kind: n.kind,
      title: n.title,
      body: n.body,
    };
    setDb((d) => ({ ...d, notifications: [note, ...d.notifications] }));
  };

  const ctx: Ctx = {
    db,
    currentUser,
    isAdmin,
    setAdmin,
    register: (data) => {
      const id = `CWD${db.nextUserNum}`;
      const user: User = {
        id,
        name: data.name,
        phone: data.phone,
        countryCode: data.countryCode,
        password: data.password,
        promo: data.promo,
        activated: false,
        banned: false,
        balance: 0,
        gains: 0,
        totalInvested: 0,
        referredBy: data.ref ?? null,
        createdAt: Date.now(),
      };
      setDb((d) => ({
        ...d,
        users: [...d.users, user],
        nextUserNum: d.nextUserNum + 1,
        currentUserId: id,
      }));
      return user;
    },
    login: (phone, password) => {
      const u = db.users.find((x) => x.phone === phone && x.password === password && !x.banned);
      if (u) setDb((d) => ({ ...d, currentUserId: u.id }));
      return u ?? null;
    },
    logout: () => setDb((d) => ({ ...d, currentUserId: null })),
    updateUser: (id, patch) =>
      setDb((d) => ({ ...d, users: d.users.map((u) => (u.id === id ? { ...u, ...patch } : u)) })),
    addGain: (userId, type, amount, detail) => {
      const entry: GainEntry = {
        id: crypto.randomUUID(),
        userId,
        type,
        amount,
        detail,
        createdAt: Date.now(),
      };
      setDb((d) => ({
        ...d,
        gains: [entry, ...d.gains],
        users: d.users.map((u) =>
          u.id === userId
            ? { ...u, balance: u.balance + amount, gains: u.gains + Math.max(0, amount) }
            : u,
        ),
      }));
    },
    recordRound: (r) => {
      const round: GameRound = { id: crypto.randomUUID(), createdAt: Date.now(), ...r };
      setDb((d) => ({
        ...d,
        rounds: [round, ...d.rounds].slice(0, 500),
        lastPlay: { ...d.lastPlay, [r.userId]: Date.now() },
      }));
    },
    canPlay: (userId) => {
      const last = db.lastPlay[userId] ?? 0;
      const gap = Date.now() - last;
      if (gap < 1200) return { ok: false, reason: "Patientez avant la prochaine partie." };
      const recent = db.rounds.filter((r) => r.userId === userId && Date.now() - r.createdAt < 60_000);
      if (recent.length >= 30) return { ok: false, reason: "Trop de parties par minute, ralentissez." };
      return { ok: true };
    },
    requestWithdraw: (req) => {
      const w: WithdrawRequest = {
        id: crypto.randomUUID(),
        status: "pending",
        createdAt: Date.now(),
        ...req,
      };
      setDb((d) => ({ ...d, withdraws: [w, ...d.withdraws] }));
      notify(req.userId, {
        kind: "withdraw",
        title: "Demande de retrait envoyée",
        body: `Votre demande de ${new Intl.NumberFormat("fr-FR").format(req.amount)} FCFA est en cours de traitement.`,
      });
      return w;
    },
    updateWithdraw: (id, patch) => {
      const w = db.withdraws.find((x) => x.id === id);
      setDb((d) => ({
        ...d,
        withdraws: d.withdraws.map((x) =>
          x.id === id ? { ...x, ...patch, resolvedAt: patch.status && patch.status !== "pending" ? Date.now() : x.resolvedAt } : x,
        ),
      }));
      if (w && patch.status === "paid") {
        notify(w.userId, {
          kind: "withdraw",
          title: "Retrait payé ✓",
          body: `Votre retrait de ${new Intl.NumberFormat("fr-FR").format(w.amount)} FCFA a été payé.`,
        });
      } else if (w && patch.status === "rejected") {
        // refund
        setDb((d) => ({
          ...d,
          users: d.users.map((u) => (u.id === w.userId ? { ...u, balance: u.balance + w.amount } : u)),
        }));
        notify(w.userId, {
          kind: "withdraw",
          title: "Retrait rejeté",
          body: `Motif : ${patch.reason ?? "non précisé"}. Le montant a été recrédité.`,
        });
      }
    },
    requestActivation: (userId) => {
      const u = db.users.find((x) => x.id === userId);
      const existing = db.activations.find((a) => a.userId === userId && a.status === "pending");
      if (existing) return existing;
      const req: ActivationRequest = {
        id: crypto.randomUUID(),
        userId,
        userName: u?.name ?? userId,
        phone: u?.phone ?? "",
        status: "pending",
        createdAt: Date.now(),
      };
      setDb((d) => ({ ...d, activations: [req, ...d.activations] }));
      notify(userId, {
        kind: "activation",
        title: "Paiement en vérification",
        body: "Votre demande d'activation est en cours de vérification par l'administrateur.",
      });
      return req;
    },
    approveActivation: (id) => {
      const a = db.activations.find((x) => x.id === id);
      if (!a) return;
      setDb((d) => ({
        ...d,
        activations: d.activations.map((x) => (x.id === id ? { ...x, status: "approved", resolvedAt: Date.now() } : x)),
        users: d.users.map((u) => (u.id === a.userId ? { ...u, activated: true } : u)),
      }));
      // referral commissions
      const user = db.users.find((u) => u.id === a.userId);
      if (user?.referredBy) {
        const lvl1 = db.users.find((u) => u.id === user.referredBy);
        if (lvl1) {
          const entry: GainEntry = { id: crypto.randomUUID(), userId: lvl1.id, type: "referral", amount: 500, detail: `Filleul ${user.id}`, createdAt: Date.now() };
          setDb((d) => ({
            ...d,
            gains: [entry, ...d.gains],
            users: d.users.map((u) => (u.id === lvl1.id ? { ...u, balance: u.balance + 500, gains: u.gains + 500 } : u)),
          }));
          notify(lvl1.id, { kind: "system", title: "Commission filleul N1", body: `+500 FCFA pour l'activation de ${user.id}.` });
          if (lvl1.referredBy) {
            const lvl2 = db.users.find((u) => u.id === lvl1.referredBy);
            if (lvl2) {
              const e2: GainEntry = { id: crypto.randomUUID(), userId: lvl2.id, type: "referral", amount: 250, detail: `Filleul N2 ${user.id}`, createdAt: Date.now() };
              setDb((d) => ({
                ...d,
                gains: [e2, ...d.gains],
                users: d.users.map((u) => (u.id === lvl2.id ? { ...u, balance: u.balance + 250, gains: u.gains + 250 } : u)),
              }));
              notify(lvl2.id, { kind: "system", title: "Commission filleul N2", body: `+250 FCFA pour l'activation de ${user.id}.` });
            }
          }
        }
      }
      notify(a.userId, {
        kind: "activation",
        title: "Compte activé ✓",
        body: "Votre compte est activé. Retraits, Mini Games et parrainage débloqués.",
      });
    },
    rejectActivation: (id, reason) => {
      const a = db.activations.find((x) => x.id === id);
      if (!a) return;
      setDb((d) => ({
        ...d,
        activations: d.activations.map((x) => (x.id === id ? { ...x, status: "rejected", reason, resolvedAt: Date.now() } : x)),
      }));
      notify(a.userId, { kind: "activation", title: "Activation refusée", body: `Motif : ${reason}` });
    },
    sendChat: (userId, from, text) => {
      const msg: ChatMessage = {
        id: crypto.randomUUID(),
        userId,
        from,
        text,
        createdAt: Date.now(),
      };
      setDb((d) => ({ ...d, chats: [...d.chats, msg] }));
      if (from === "admin" && userId !== db.currentUserId) {
        notify(userId, { kind: "support", title: "Nouveau message du support", body: text.slice(0, 120) });
      }
      if (from === "user") {
        setTimeout(() => {
          const auto: ChatMessage = {
            id: crypto.randomUUID(),
            userId,
            from: "admin",
            text: "Votre demande a été transmise à un administrateur qui vous contactera prochainement.",
            createdAt: Date.now(),
          };
          setDb((d) => ({ ...d, chats: [...d.chats, auto] }));
          notify(userId, { kind: "support", title: "Support", body: "Votre demande a été transmise à un administrateur." });
        }, 1500);
      }
    },
    addPromo: (p) => setDb((d) => ({ ...d, promos: [...d.promos, p] })),
    notify,
    markAllRead: (userId) =>
      setDb((d) => ({
        ...d,
        notifications: d.notifications.map((n) => (n.userId === userId ? { ...n, read: true } : n)),
      })),
  };

  return <StoreCtx.Provider value={ctx}>{children}</StoreCtx.Provider>;
}

export function useStore() {
  const ctx = useContext(StoreCtx);
  if (!ctx) throw new Error("StoreProvider missing");
  return ctx;
}

export function findCountry(code: string) {
  return COUNTRIES.find((c) => c.code === code) ?? COUNTRIES[0];
}

export function formatFCFA(n: number) {
  return new Intl.NumberFormat("fr-FR").format(Math.round(n)) + " FCFA";
}
